import { RootContainer } from "./minecraft";
declare module '@kasugalib/registry' {
    interface Registries {
        'kasuga_lib:gui': (root: RootContainer) => void;
    }
}
export declare function registerComponent(id: string, render: (root: RootContainer) => void): void;
declare const _default: {
    registerComponent: typeof registerComponent;
};
export default _default;
export * from './minecraft';
