import { Node, RootContainer } from "../minecraft";
export declare function createContainerFor(document: Document, root: HTMLElement, params: any): RootContainer;
export declare function createNode(document: Document, name: string): Node;
export declare function adaptNode(root: HTMLElement): Node;
