export declare function parseUV(string: string, width: number, height: number): [number, number, number, number];
export declare function adaptStyle(name: string, value: string, root: HTMLElement, styles: any[], container: any): boolean;
