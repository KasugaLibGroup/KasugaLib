export declare function polyfillLoader(target: Partial<typeof globalThis>): void;
