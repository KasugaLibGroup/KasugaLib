export declare function initializeRuntime(target: Partial<typeof globalThis>): void;
export type {} from './native';
