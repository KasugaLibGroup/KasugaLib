export declare function polyfillTimer(target: Partial<typeof globalThis>): void;
