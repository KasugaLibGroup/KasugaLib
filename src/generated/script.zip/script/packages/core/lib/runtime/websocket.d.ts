export declare function polyfillWebsocket(target: Partial<typeof globalThis>): void;
