export interface Registries {
}
export declare function getRegistry<T extends keyof Registries>(registry: T): Registry<Registries[T]>;
export declare class Registry<T> {
    nativeInterface: any;
    constructor(name: string);
    register(name: string, item: T): void;
}
declare const _default: {
    getRegistry: typeof getRegistry;
};
export default _default;
